import React, { useContext, useEffect } from 'react'
import logo from "./Card-2.png"
import Navbar from './Navbar'
import { NavLink } from 'react-router-dom'
import Footer from './Footer'
import navContext from './Context/navContext'


export default function HomePage(props) {

    const context = useContext(navContext);
    const {logstate,setTitle} = context;

    useEffect(()=>{
        setTitle("home");
    },[setTitle])

    return (
        <div className='background'>
        <Navbar/>
        {logstate===0 && <div className="fw-bold fs-3 mt-5 alert alert-warning" role="alert">Login to access restaurants and other features.</div>}
        <div style={{display: "flex", alignItems:"center", justifyContent:"center", flexWrap: "wrap",height:"81vh"}}>
            <div className="card" style={{maxWidth: 18 +"rem", margin: "0rem 2rem"}}>
                <img src={logo} className="card-img-top" alt="..." />
                <div className="card-body">
                    <h5 className="card-title">Create Profile</h5>
                    <p className="card-text">Create a profile to get started. You can add your restaurants, menu card and other information.</p>
                    <NavLink to={logstate===0?"/login":"/restaurant"} className="btn btn-primary">{logstate===0?"Sign-in":"Edit Profile"}</NavLink>
                </div>
            </div>
            <div className="card" style={{maxWidth: 18 +"rem", margin: "0rem 2rem"}}>
                <img src={logo} className="card-img-top" alt="..." />
                <div className="card-body">
                    <h5 className="card-title">How to use</h5>
                    <p className="card-text">To know what this website provides, and manage multiple restaurants details - Click the button below.</p>
                    <NavLink to="/about" className="btn btn-primary">Read Content</NavLink>
                </div>
            </div>
            <div className="card" style={{maxWidth: 18 +"rem", margin: "0rem 2rem"}}>
                <img src={logo} className="card-img-top" alt="..." />
                <div className="card-body">
                    <h5 className="card-title">Features</h5>
                    <p className="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                    <NavLink to={logstate===0?"/login":"/orderpage"} className="btn btn-primary">Order Food</NavLink>
                </div>
            </div>
        </div>
        {logstate===1 && <Footer/>}
        </div>
    )
}
