import { createContext } from "react";

const navContext = createContext();

export default navContext;